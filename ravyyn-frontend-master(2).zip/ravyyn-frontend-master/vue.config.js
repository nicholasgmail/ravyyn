module.exports = {
    lintOnSave: false,
    devServer: {
        https:true
    }
}