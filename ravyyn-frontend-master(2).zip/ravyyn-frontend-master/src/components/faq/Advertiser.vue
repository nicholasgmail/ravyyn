<template>
    <!-- BEGINNING OF ADVERTISERS FAQS -->

          <div class="faqs faqsDisplay" id="advertisersFaqs">
            
            <div class="faqRow">
              <div class="faqTitle">
                <p>How can I be sure I am not paying for an Influencer with fake followers ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Upon sign up, our exclusive software automatically scans the Influencer’s instagram profile, checking for red flags such as suspiciously low engagement rates, fake followers, or a spam profile. This ensures the integrity of our influencers, and results in a fake free zone.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Is there a setup fee or subscription fee ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Nope! Sign-up is totally free, and you will never be charged extraneous fees. You only pay per post, and can adjust the prerequisites of each campaign to fit your existing budget.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>When does payment get charged to my credit card ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>You’ll be charged when, and only when, the campaign is successfully completed.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>How do I post a campaign ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Click <a href="#">here</a> to check out our different campaign options and get started! It’s super easy, we promise. Simply pick your budget, select your Influencer, and advertise to your heart's content.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>How do I send my product to an influencer ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>You can negotiate the details of product shipping through our live chat feature with the Influencers of your choice. We will be automating this process shortly!</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>What if an influencer published an incorrect post?  ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Influencers have a 2 hour window to correct any errors in the post upon initial posting. In the rare event the influencer does not correct the post, please contact us through live chat or at info@ravyyn.com and we'll rectify the situation. You won't be charged for posts not published as agreed.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Why is no one applying to my campaign ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>If you’re not getting a ton of responses, you may want to edit your post to have broader influencer prerequisites or your budget placed may be too low. You can also invite Influencers to apply directly. Feel free to send us a message through live chat or an email at info@ravyyn.com and we can take a look at your campaign and give you some pointers.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>How do I know if my campaign was successful ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>You’ll be able to see the analytics of each post on your dashboard, allowing you to track the progress of each campaign, measure responses, and watch your brand grow.</p>
                <p></p>
              </div>
            </div>

          </div>
          <!-- END OF ADVERTISERS FAQ -->
</template>

<script>
import FAQMixin from '@/mixins/faqMixin'

export default {
    name: 'AdvertiserFAQ',
    mixins: [FAQMixin]
}
</script>

<style lang="scss">
  .advertisersFaqs {
    display: block;
  }
</style>