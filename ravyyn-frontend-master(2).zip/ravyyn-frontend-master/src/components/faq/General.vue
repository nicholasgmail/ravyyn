<template>
     <div class="faqs faqsDisplay" id="generalFaqs">
            
            <div class="faqRow">
              <div class="faqTitle">
                <p>What is an influencer ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>We define an Influencer as anybody with a social media presence that wants to use their platform to advertise products, brands, and businesses to their followers.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Who are our advertisers ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Our Advertisers are brands and businesses of all sizes that want to use the power of social media to boost their brand awareness and increase sales.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>What is your refund policy ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>If there are any issues with an Advertiser’s campaign we will re-credit the account for our user to try another campaign, if the user is still not happy with our service, we will give a full refund to that user.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Is Ravyyn a global platform ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Yes! Ravyyn is a great tool to connect with Influencers and Advertisers around the world.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>What social media platforms can I use Ravyyn for ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Currently, Ravyyn is compatible with Instagram, but we plan on expanding to include additional platforms (hint hint- TikTok!) in the near future. Make sure to follow Ravyyn on Instagram to stay ahead of the curve on the newest features.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>What about Instagrams advertising regulations ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>﻿We require every post to include #ad and #ravyyn as hashtags, so that every influencer automatically stays within Instagrams current advertising guidelines, and followers are aware that they are viewing a sponsored post.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>How does Ravyyn make money ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>We take a tiny percentage fee (only 10%) from each transaction. We hate to do it, but we really like tacos and tacos cost money.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Who generates the content ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Ravyyn currently offers two different content flows. You can have the Influencer post an existing ad of your choosing, or have them create a custom one according to your specifications. Our super simple chat feature allows you to collaborate as much or as little as you want!</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Who owns the content ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>The Influencer is the owner of the content once it is posted on their page. A brand can share an Influencer's post within the platform it appears, but cannot use the content for any advertising outside of that.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>How long is an influencer required to leave a post on their page ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>An Influencer is required to leave the post up for a full 24 hours for maximum visibility. After that they can take it down or leave it up if they really love it.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>What if an influencer doesn't deliver ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>We only charge the Advertiser upon completion of the job. If an Influencer falls through, we’ll give you the option to be matched with a different one or cancel the campaign. Either way, an advertiser won’t be charged until the campaign has been completed in its entirety.
                <br> 
            	We take Influencer performance very seriously, and have the ability to suspend an account immediately. If you feel a member has breached our guidelines, please notify us at info@ravyyn.com</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>What is engagement rate ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>The engagement rate is an algorithm (likes plus comments divided by followers) that helps us determine the success, reach, and value of a post or Influencer.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Why is Ravyyn so affordable ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Our goal is to make influencer marketing affordable for everyone, regardless of their marketing budget. We accomplish this through automation, customization, and just a little bit of magic.</p>
                <p></p>
              </div>
            </div>
          </div>
          <!-- END OF GENERAL FAQ -->
</template>

<script>
import FAQMixin from '@/mixins/faqMixin'

export default {
    name: 'GeneralFAQ',
    mixins: [FAQMixin]
}
</script>