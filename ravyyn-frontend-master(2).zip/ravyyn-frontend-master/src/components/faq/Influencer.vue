<template>
     <!-- BEGINNING OF INFLUENCERS FAQS -->

          <div class="faqs faqsDisplay" id="influencersFaqs">
            
            <div class="faqRow">
              <div class="faqTitle">
                <p>How do I get paid ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Influencers get paid automatically via PayPal within 3 days of job completion.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Do I have to have a lot of followers to be an Influencer ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Nope! Unlike other platforms, Ravyyn embraces the power of the micro influencer. Influencers with smaller followings are perfect matches for local advertisers, while macro-influencers work well with global brands. Think of it this way; if you owned a coffee shop in your hometown, would you rather advertise in the newspaper of a big city several hours away or the newspaper that you know your neighbors will see?</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Can I get paid to help spread the word about Ravyyn ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Yup! Reach out directly on our Instagram or shoot us an email at info@ravyyn.com to learn how you can get paid to post about Ravyyn.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Is there such a thing as too many posts ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>For sure. That’s why you’re only able to have one sponsored post running at a time. If your followers feel like your feed is all ads, you’ll start to lose your influence. We encourage you to find your own sweet spot.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Why do I have to put a link in my bio when I sign up ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Our awesome developers came up with a super easy way to sync your instagram with the Ravyyn platform so that we can show your profile to interested Advertisers exactly as they’d see it on Instagram. Just copy + paste the custom link in your bio, and once your profile is linked and confirmed, go ahead and delete it. We NEVER collect, store, or sell your personal data.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>Can I get gifted products ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>Yes. Many of our Advertisers send Influencers products to create custom content for them. If a campaign includes a product, you’ll see a little gift icon. If selected for that campaign, you and the Advertiser can communicate directly through our chat feature to hammer out the details.</p>
                <p></p>
              </div>
            </div>

            <div class="faqRow">
              <div class="faqTitle">
                <p>How is my Influencer rating calculated ?</p>
                <p class="faqDropDown"></p>
              </div>
              <div class="faqInfo">
                <p>After every campaign, Advertisers are encouraged to review the Influencer they worked with for things like communication, job completion, and overall satisfaction. The higher your rating as an influencer, the more campaigns you’ll get! You can increase your Influencer rating by communicating in a polite and timely manner, posting accurately, and creating cool content.</p>
                <p></p>
              </div>
            </div>

          </div>
          <!-- END OF INFLUENCERS FAQ -->
</template>

<script>
import FAQMixin from '@/mixins/faqMixin'

export default {
    name: 'InfluencerFAQ',
    mixins: [FAQMixin]
}
</script>