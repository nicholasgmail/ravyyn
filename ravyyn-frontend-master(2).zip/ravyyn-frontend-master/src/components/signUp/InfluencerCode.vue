<template>

  <div>
    <img
      src="../../assets/icons/instagram-color-icon.png"
      alt="instagram logo"
      class="d-block mx-auto my-5"
    />
    <h4 class="font-la-nord px-18 text-primary">
      Copy & Paste this Code in Your Instagram Bio
    </h4>

    <p class="position-relative text-center px-13 p-0 mb-4">
      (You can Delete Immediately Upon Confirmation)
      <span
        id="influencerSignupInstagram"
        class="tool whats-this-icon position-absolute"
        data-tip="Some instruction here"
        tabindex="1"
      ></span>
    </p>
    <div class="content-wrap border-0 mx-auto position-relative">
      <form class="mb-40" @submit.stop.prevent>
        <div class="ig-code-field position-relative">
          <p id="ig-code-copied">Code copied to clipboard!</p>
          <p id="influencer-ig-code" class="text-left">{{ code }}</p>
          <button
            id="copy-influencer-ig-code-btn"
            class="border border-dark bg-white"
            @click="copyCode"
          >
            <span class="sr-only"
              >Button to copy instagram code to clipboard</span
            >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
            >
              <path
                id="Icon_awesome-link"
                data-name="Icon awesome-link"
                d="M15.31,8.69a7.121,7.121,0,0,1,.017,10.059l-.017.017-3.15,3.15A7.125,7.125,0,1,1,2.084,11.84L3.823,10.1a.749.749,0,0,1,1.279.5,8.637,8.637,0,0,0,.454,2.471.754.754,0,0,1-.177.779l-.613.613a3.375,3.375,0,1,0,4.742,4.8l3.15-3.15a3.374,3.374,0,0,0,0-4.773,3.511,3.511,0,0,0-.485-.4.752.752,0,0,1-.326-.591,1.867,1.867,0,0,1,.548-1.4l.987-.987a.753.753,0,0,1,.965-.081,7.148,7.148,0,0,1,.962.806Zm6.606-6.607a7.133,7.133,0,0,0-10.076,0L8.69,5.234l-.017.017a7.126,7.126,0,0,0,.979,10.865.753.753,0,0,0,.965-.081l.987-.987a1.867,1.867,0,0,0,.548-1.4.752.752,0,0,0-.326-.591,3.511,3.511,0,0,1-.485-.4,3.374,3.374,0,0,1,0-4.773l3.15-3.15a3.375,3.375,0,1,1,4.742,4.8l-.613.613a.754.754,0,0,0-.177.779A8.638,8.638,0,0,1,18.9,13.4a.749.749,0,0,0,1.279.5l1.739-1.739a7.133,7.133,0,0,0,0-10.076Z"
                transform="translate(0 0)"
              />
            </svg>
          </button>
        </div>
            <b-alert
              :show="dismissCountDown"
              variant="success"
              @dismissed="dismissCountDown=0"
              @dismiss-count-down="countDownChanged"
            >
      Code copied to clipboard! 
    </b-alert>
        <input
          @click="onSubmit"
          value="Confirm"
          id="influencer-ig-code-confirm"
          class="btn btn-lg px-1 d-block"
        />
      </form>
      <p class="text-center mb-40"><router-link to="paypal" class="skip-for-now fs-sm text-primary font-poppins">Skip For Now</router-link></p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      code: '',
      dismissSecs: 1.5,
      dismissCountDown: 0
    };
  },
  beforeMount() {
    this.$http
      .get("/influencer/instagram_code")
      .then((res) => this.code = res.data.instagramCode)
  },
  methods: {
    countDownChanged(dismissCountDown) {
        this.dismissCountDown = dismissCountDown
    },
    copyCode() {
      navigator.clipboard.writeText(this.code);
      this.dismissCountDown = this.dismissSecs;
    },
    onSubmit() {
        this.$router.push('paypal')
    }
  },
};
</script>