  
export const tagIs = {
    props: {
      tag: {
        type: String,
        default: 'div',
        required: false
      }
    }
  }