<?php

	require_once(__dir__."/System/settings/main.php" );
	require_once(DOC_ROOT."/System/settings/session.php" );
	if (!isValidSession()) { header("Location: login.php"); exit();	}
	require_once(DOC_ROOT."/System/classes/Admin.class.php" );

	if (getFromSession("Permissions")["ManageAdmins"] != "true") {
		header("Location: index.php");
		exit();
	}
	
	$Admin = new Admin();
	$AdminUsers = $Admin->getUsers();

	if (isset($_POST["Action"])) {
		//dump($_POST);die();
		if ($_POST["Action"] == "Status") {
			$ok = $Admin->updateStatus($_POST["UserID"],$_POST["Status"]);
			if (!$ok) {
				die("ERROR: ".$Admin->getLastError());
			}			
			header("Location: admin_users.php");
			exit();
		} else if ($_POST["Action"] == "Reset") {
			$ok = $Admin->updatePassword($_POST["UserID"],$_POST["Password"]);
			if (!$ok) {
				die("ERROR: ".$Admin->getLastError());
			}
			header("Location: admin_users.php");
			exit();
		} else if ($_POST["Action"] == "EditUser") {
			$Permissions = $_POST;
			unset($Permissions["UserID"]);
			unset($Permissions["Action"]);
			//dump($Permissions);die();
			$ok = $Admin->updatePermissions($_POST["UserID"],$Permissions);
			if (!$ok) {
				die("ERROR: ".$Admin->getLastError());
			}
			header("Location: admin_users.php");
			exit();
		} else {
			$ok = $Admin->create($_POST);
			if (!$ok) {
				if (stristr($Admin->getLastError(),"Duplicate")) {
					$err = "Username already exists. Please try again.";
					header("Location: admin_users.php?err=$err");
					exit();
				} else {
					die("ERROR: ".$Admin->getLastError());
				}
			} else {
				header("Location: admin_users.php");
				exit();
			}
		}
	}

?>
<!DOCTYPE html>
<!--[if IE 8]> 
<html lang="en" class="ie8 no-js">
  <![endif]-->
  <!--[if IE 9]> 
  <html lang="en" class="ie9 no-js">
    <![endif]-->
    <!--[if !IE]><!-->
    <html lang="en">
      <!--<![endif]-->
      <!-- BEGIN HEAD -->
      <head>
        <meta charset="utf-8" />
        <title>paypyr.com Admin Dashboard</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="" name="description" />
        <meta content="" name="author" />

      <?php require_once("styles.php"); ?>
       
        <link rel="shortcut icon" href="favicon.ico" />
      </head>
      <!-- END HEAD -->
      <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
        <div class="page-wrapper">
        <!-- BEGIN HEADER -->
        <?php include('header.php'); ?>
        <!-- END HEADER -->
        <!-- BEGIN HEADER & CONTENT DIVIDER -->
      <div class="clearfix"> </div>
        <!-- END HEADER & CONTENT DIVIDER -->
        <!-- BEGIN CONTAINER -->
        <div class="page-container">
          <!-- BEGIN SIDEBAR -->
          <?php include('navigation.php'); ?>
          <!-- END SIDEBAR -->
          <!-- BEGIN CONTENT -->
          <div class="page-content-wrapper">
            <!-- BEGIN CONTENT BODY -->
            <div class="page-content">
              <!-- BEGIN PAGE HEADER-->
              <!-- BEGIN PAGE BAR -->
              <div class="page-bar">
                <ul class="page-breadcrumb">
                  <li>
                    <a href="index.php">Home</a>
                    <i class="fa fa-circle"></i>
                  </li>
                  <li>
                    <span>Admin Users</span>
                  </li>
                </ul>
              </div>
              <!-- END PAGE BAR -->
              <!-- BEGIN PAGE TITLE-->
              <h1 class="page-title"> Admin Users
                
              </h1>
              <!-- MAIN CONTENT START-->
              <div class="row">
                <div class="col-md-12">
                  <!-- BEGIN EXAMPLE TABLE PORTLET-->
                  <div class="portlet light bordered">
                    <div class="portlet-title">
                      <div class="caption font-dark">
                        <i class="icon-settings font-dark"></i>
                        <span class="caption-subject bold uppercase"> Users </span>
                      </div>
                    </div>
                    <div class="portlet-body">
                      <div class="table-toolbar ">
                        <div class="row">
                         
                          <!-- POPUP MODAL START -->
                          <div class="modal fade" id="modReset" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                               <div class="modal-content">
                                  <div class="modal-header">
                                     <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                     <h4 class="modal-title" >Reset Password</h4>
                                  </div>
                                  <div class="modal-body">
                                    <div class="portlet-body form">
                                        <form class="form-horizontal" method="post" role="form" id="frmReset">
                                            <div class="form-body">
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">New Password</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="Enter text" id="txtChangePassword" name="txtChangePassword">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Confirm Password</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="Enter text" id="txtConfirmPassword" name="txtConfirmPassword">
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                     <button type="button" class="btn dark btn-outline" data-dismiss="modal" id="btnCloseReset">Close</button>
                                     <button type="button" class="btn green" name="btnSubmitReset" id="btnSubmitReset">Reset Password</button>
                                  </div>
                               </div>
                            <!-- /.modal-content -->
                            </div>
                          <!-- /.modal-dialog -->
                          </div>
                          
                          <div class="modal fade" id="modStatus" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                               <div class="modal-content">
                                  <div class="modal-header">
                                     <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                     <h4 class="modal-title" >Change Status</h4>
                                  </div>
                                  <div class="modal-body">
                                    <div class="portlet-body form">
                                        <form class="form-horizontal" method="post" role="form" id="frmStatus">
                                            <div class="form-body">
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Current Status</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="Enter text" id="txtStatus" name="txtStatus" readonly>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">New Status</label>
                                                    <div class="col-md-9">
                                                        <select class="form-control" id="selStatus" name="selStatus">
                                                        	<option value="-1">Select New Status</option>
                                                        	<option value="0">Inactive</option>
                                                        	<option value="1">Active</option>
														</select>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                     <button type="button" class="btn dark btn-outline" data-dismiss="modal" id="btnCloseReset">Close</button>
                                     <button type="button" class="btn green" name="btnSubmitStatus" id="btnSubmitStatus">Update Status</button>
                                  </div>
                               </div>
                            <!-- /.modal-content -->
                            </div>
                          <!-- /.modal-dialog -->
                          </div>
                          
                          <div class="modal fade" id="modNewUser" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                               <div class="modal-content">
                                  <div class="modal-header">
                                     <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                     <h4 class="modal-title" >Add New User</h4>
                                  </div>
                                  <div class="modal-body">
                                    <div class="portlet-body form">
                                        <form class="form-horizontal" method="post" role="form" id="frmNewUser">
                                            <div class="form-body">
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Username</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="Enter text" id="txtNewUsername" name="txtNewUsername">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">New Password</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="Enter text" id="txtNewPassword" name="txtNewPassword">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Permissions</label>
                                                    <div class="col-md-9">
                                                        <input type="checkbox" id="chkUsers" name="chkUsers"> Manage Admin Users<br>
                                                        <input type="checkbox" id="chkAccounting" name="chkAccounting"> Manage Accounting<br>
                                                        <input type="checkbox" id="chkCampaigns" name="chkCampaigns"> Manage Campaigns<br>
                                                        <input type="checkbox" id="chkInfluencers" name="chkInfluencers"> Manage Influencers<br>
                                                        <input type="checkbox" id="chkAdvertisers" name="chkAdvertisers"> Manage Advertisers<br>
                                                        <input type="checkbox" id="chkSettings" name="chkSettings"> Manage Settings<br>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                     <button type="button" class="btn dark btn-outline" data-dismiss="modal" id="btnCloseNew">Close</button>
                                     <button type="button" class="btn green" name="btnSubmitNew" id="btnSubmitNew">Create New User</button>
                                  </div>
                               </div>
                            <!-- /.modal-content -->
                            </div>
                          <!-- /.modal-dialog -->
                          </div>
                          
                          <div class="modal fade" id="modEditUser" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                               <div class="modal-content">
                                  <div class="modal-header">
                                     <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                     <h4 class="modal-title" >Update Permissions</h4>
                                  </div>
                                  <div class="modal-body">
                                    <div class="portlet-body form">
                                        <form class="form-horizontal" method="post" role="form" id="frmEdit">
                                            <div class="form-body">
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Username</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="Enter text" id="txtEditUsername" name="txtEditUsername" readonly>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Permissions</label>
                                                    <div class="col-md-9">
                                                        <input type="checkbox" id="chkEUsers" name="chkEUsers"> Manage Admin Users<br>
                                                        <input type="checkbox" id="chkEAccounting" name="chkEAccounting"> Manage Accounting<br>
                                                        <input type="checkbox" id="chkECampaigns" name="chkECampaigns"> Manage Campaigns<br>
                                                        <input type="checkbox" id="chkEInfluencers" name="chkEInfluencers"> Manage Influencers<br>
                                                        <input type="checkbox" id="chkEAdvertisers" name="chkEAdvertisers"> Manage Advertisers<br>
                                                        <input type="checkbox" id="chkESettings" name="chkESettings"> Manage Settings<br>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                     <button type="button" class="btn dark btn-outline" data-dismiss="modal" id="btnCloseNew">Close</button>
                                     <button type="button" class="btn green" name="btnSubmitEdit" id="btnSubmitEdit">Update User</button>
                                  </div>
                               </div>
                            <!-- /.modal-content -->
                            </div>
                          <!-- /.modal-dialog -->
                          </div>
                          
                          <!-- POPUP MODAL END -->
                        </div>
                      </div>
                      
						  <button type="button" id="btnNewUser" class="btn blue"><i class="fa fa-plus icon-white"></i> Add New User</button>
                      		<br><br>
                      <table class="table table-striped table-bordered table-hover order-column" id="tblAdminUsers">
                        <thead>
                          <tr>
                            <th> UserID </th>
                            <th> Status </th>
                            <th> Username </th>
                            <th> Date Created </th>
                            <th> Option </th>
                          </tr>
                        </thead>
                        
                      </table>
                    </div>
                  </div>
                  <!-- END EXAMPLE TABLE PORTLET-->
                </div>
              </div>
              <!-- MAIN CONTENT END-->
              <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
          </div>
          <!-- END CONTAINER -->
          <!-- BEGIN FOOTER -->
          <?php include('footer.php'); ?>
          <!-- END FOOTER -->
      </div>
        <!--[if lt IE 9]>
        <script src="assets/global/plugins/respond.min.js"></script>
        <script src="assets/global/plugins/excanvas.min.js"></script> 
        <script src="assets/global/plugins/ie8.fix.min.js"></script> 
        <![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="assets/global/scripts/datatable.js" type="text/javascript"></script>
        <script src="assets/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="assets/pages/scripts/table-datatables-managed.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="assets/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
        <script src="assets/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="assets/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <script>
          $(document).ready(function()
          {
			  
<?php
	if (isset($_GET["err"]) && $_GET["err"] != "") {
		echo "alert('".$_GET["err"]."');";
	}
?>
			  
              $('#clickmewow').click(function()
              {
                  $('#radio1003').attr('checked', 'checked');
              });
			  
			  var tableData = [
<?php
	foreach ($AdminUsers as $AU) {
		$Status = ($AU["Status"]=="1")?"Active":"Inactive";
		$selID = uniqid();
		echo "[".NL;
		echo "'".$AU["UserID"]."',".NL;
		echo "'".$Status."',".NL;
		echo "'".$AU["Username"]."',".NL;
		echo "'".date("m/d/Y H:i:s",strtotime($AU["CreateDate"]))."',".NL;
		echo "'<button type=\"button\" id=\"btnReset\" UserID=\"".$AU["UserID"]."\" class=\"btn green\" alt=\"Reset Password\"><i class=\"fa fa-lock icon-white\"></i></button> ";
		echo "<button type=\"button\" id=\"btnUpdate\" Username=\"".$AU["Username"]."\" UserID=\"".$AU["UserID"]."\" class=\"btn blue\" alt=\"Update Permissions\"><i class=\"fa fa-eye icon-white\"></i></button> ";
		echo " <button type=\"button\" id=\"btnStatus\" Status=\"".$Status."\" StatusID=\"".$AU["Status"]."\" UserID=\"".$AU["UserID"]."\" class=\"btn red\" alt=\"Update Status\"><i class=\"fa fa-user icon-white\"></i></button>'".NL;
		echo "],\n".NL;
	}
	
?>			  
			  ];
			  
			  Permissions = {
<?php
	foreach ($AdminUsers as $AU) {
		echo "'u_".$AU["UserID"]."':";
		echo $AU["Permissions"];
		echo ",\n".NL;
	}
	
?>			  
			  };			  
			  
			  var mytable = $('#tblAdminUsers').DataTable( {
				 	data: tableData
			  });
			  
			  var UserID = null;
			  var Status = null;
			  var StatusID = null;
			  $('[id=btnReset]').on('click',function(){
				  UserID = $(this).attr('UserID');
				  $('#modReset').modal('toggle');
			  });
			  
			  $('[id=btnStatus]').on('click',function(){
				  UserID = $(this).attr('UserID');
				  Status = $(this).attr('Status');
				  StatusID = $(this).attr('StatusID');
				  $('#txtStatus').val(Status);
				  $('#modStatus').modal('toggle');
			  });
			  
			  $('[id=btnUpdate]').on('click',function(){
				  UserID = $(this).attr('UserID');
				  id = 'u_'+UserID;
				  $('#txtEditUsername').val($(this).attr('Username'));
				  $('#txtStatus').val(Status);
				  if (Permissions[id].ManageAdmins == "true") {
				  	$('#chkEUsers').attr('checked','checked');
				  }
				  if (Permissions[id].ManageAccounting == "true") {
				  	$('#chkEAccounting').attr('checked','checked');
				  }
				  if (Permissions[id].ManageCampaigns == "true") {
				  	$('#chkECampaigns').attr('checked','checked');
				  }
				  if (Permissions[id].ManageInfluencers == "true") {
				  	$('#chkEInfluencers').attr('checked','checked');
				  }
				  if (Permissions[id].ManageAdvertisers == "true") {
				  	$('#chkEAdvertisers').attr('checked','checked');
				  }
				  if (Permissions[id].ManageSettings == "true") {
				  	$('#chkESettings').attr('checked','checked');
				  }
				  $('#modEditUser').modal('toggle');
			  });
			  
			   $('[id=btnNewUser]').on('click',function(){
				  $('#modNewUser').modal('toggle');
			  });
			  
			  $('#btnSubmitReset').on('click',function() {
				  var Password = $('#txtChangePassword').val();
				  var CPassword = $('#txtConfirmPassword').val();
				  
				  if (Password != CPassword) {
					  alert('Password and Confirm Password do not match.');
					  return false;
				  }
				  
				  if (Password.length < 5 || Password.length > 50) {
					  alert('Password should be between 5 and 50 characters.');
					  return false;
				  }
				  
				    var form = document.createElement('form');
					form.setAttribute('method','POST');
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','UserID');
					field.setAttribute('value',UserID);
					form.appendChild(field);
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','Password');
					field.setAttribute('value',Password);
					form.appendChild(field);
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','Action');
					field.setAttribute('value','Reset');
					form.appendChild(field);
					document.body.appendChild(form);
					form.submit();
			  });
			  
			  $('#btnSubmitStatus').on('click',function() {
				  var NewStatus = $('#selStatus').val();
				  
				  if (StatusID == NewStatus) {
					  alert('New Status should be different.');
					  return false;
				  }
				  
				  if (NewStatus == -1) {
					  alert('Please select a new status.');
					  return false;
				  }
				  
				    var form = document.createElement('form');
					form.setAttribute('method','POST');
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','UserID');
					field.setAttribute('value',UserID);
					form.appendChild(field);
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','Status');
					field.setAttribute('value',NewStatus);
					form.appendChild(field);
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','Action');
					field.setAttribute('value','Status');
					form.appendChild(field);
					document.body.appendChild(form);
					form.submit();
			  });
			  
			  $('#btnSubmitNew').on('click',function() {
				  var Username = $('#txtNewUsername').val();
				  var Password = $('#txtNewPassword').val();
				  
				  if (Username == "") {
					  alert('Please enter a new Username.');
					  return false;
				  }
				  
				  if (Password.length < 5 || Password.length > 50) {
					  alert('Password should be between 5 and 50 characters.');
					  return false;
				  }
				  
				    var form = document.createElement('form');
					form.setAttribute('method','POST');
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','Username');
					field.setAttribute('value',Username);
					form.appendChild(field);
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','Password');
					field.setAttribute('value',Password);
					form.appendChild(field);
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageAdmins');
					field.setAttribute('value',$('#chkUsers').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageAccounting');
					field.setAttribute('value',$('#chkAccounting').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageCampaigns');
					field.setAttribute('value',$('#chkCampaigns').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageInfluencers');
					field.setAttribute('value',$('#chkInfluencers').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageAdvertisers');
					field.setAttribute('value',$('#chkAdvertisers').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageSettings');
					field.setAttribute('value',$('#chkSettings').is(':checked'));
					form.appendChild(field);
				    var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','Action');
					field.setAttribute('value','NewUser');
					form.appendChild(field);
					document.body.appendChild(form);
					form.submit();
			  });
			  
			  $('#btnSubmitEdit').on('click',function() {				  
				    var form = document.createElement('form');
					form.setAttribute('method','POST');
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','UserID');
					field.setAttribute('value',UserID);
					form.appendChild(field);
					var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageAdmins');
					field.setAttribute('value',$('#chkEUsers').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageAccounting');
					field.setAttribute('value',$('#chkEAccounting').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageCampaigns');
					field.setAttribute('value',$('#chkECampaigns').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageInfluencers');
					field.setAttribute('value',$('#chkEInfluencers').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageAdvertisers');
					field.setAttribute('value',$('#chkEAdvertisers').is(':checked'));
					form.appendChild(field);
				  var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','ManageSettings');
					field.setAttribute('value',$('#chkESettings').is(':checked'));
					form.appendChild(field);
				    var field = document.createElement('input');
					field.setAttribute('type','hidden');
					field.setAttribute('name','Action');
					field.setAttribute('value','EditUser');
					form.appendChild(field);
					document.body.appendChild(form);
					form.submit();
			  });
			  
          });
        </script>
      </body>
    </html>